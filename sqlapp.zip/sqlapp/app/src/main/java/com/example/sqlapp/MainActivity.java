package com.example.sqlapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void button1(View view)
    {
        Intent i = new Intent(this, ResultsActivity.class);
        i.putExtra("query", "SELECT CategoryName, ProductName, UnitPrice FROM Products, Categories WHERE Categories.CategoryID=Products.CategoryID ORDER BY CategoryName;");
        startActivity(i);
    }

    public void button2(View view)
    {
        Intent i = new Intent(this, ResultsActivity.class);
        i.putExtra("query", "SELECT CategoryName, ProductName, UnitPrice FROM Products, Categories WHERE Categories.CategoryID=Products.CategoryID ORDER BY UnitPrice" );
        startActivity(i);
    }

    public void button3(View view)
    {
        Intent i = new Intent(this, ResultsActivity.class);
        i.putExtra("query", "SELECT CategoryName, ProductName, UnitPrice FROM Products, Categories WHERE Categories.CategoryID=Products.CategoryID AND UnitPrice < 25 ORDER BY UnitPrice ");
        startActivity(i);
    }

    public void button4(View view)
    {
        Intent i = new Intent(this, ResultsActivity.class);
        i.putExtra("query", "SELECT CategoryName, ProductName, UnitPrice FROM Products, Categories WHERE Categories.CategoryID=Products.CategoryID AND UnitPrice >= 25 ORDER BY UnitPrice ");
        startActivity(i);
    }

    public void button5(View view)
    {
        Intent i = new Intent(this, ResultsActivity.class);
        i.putExtra("query" , "Select CategoryName, COUNT(CategoryName) from Products INNER join Categories on Categories.CategoryID=Products.CategoryID GROUP BY CategoryName order by Count(CategoryName)");
        startActivity(i);
    }


}
